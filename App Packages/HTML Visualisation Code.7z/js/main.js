$(function () {

    $.getJSON('data.json', function (data) {
		
		 // Make codes uppercase to match the map data
        $.each(data, function () {
            this.flag = this.code.replace('UK', 'GB').toLowerCase();
        });
		
		
		
		
		        function pointClick() {
					var row = this.options.row,
                    $div = $('<div><p> this is a paragraph</div>')
                        .dialog({
							title: this.name,
							
						});
						
					window.chart = new Highcharts.Chart({
						chart: {
							renderTo: $div[0],
							type: 'pie',
						},
						title:{
							text: 'This is a Test'
						},
						series: [{
							name: 'Votes',
							data: [{
								name: 'Obama',
								color: '#0200D0',
								y: 56
							}, {
								name: 'Romney',
								color: '#C40401',
								y: 54
							}],
							dataLabels: {
								format: '<b>{point.name}</b> {point.percentage:.1f}%'
							}
                        
                    }]
					});
					
				}
		
		
		
		
		
		
		
		
		
	// Initiate the chart
    Highcharts.mapChart('container', {

        title: {
            text: 'Kickstarter Projects'
        },

        subtitle: {
            text: 'Source: <a href="https://www.kaggle.com/kemical/kickstarter-projects/data"> Kickstarter:</a>'
        },

        mapNavigation: {
            enabled: true,
            buttonOptions: {
                verticalAlign: 'bottom'
            }
        },

        colorAxis: {
			dataClasses: [{
				from: 0,
				to: .0001,
				name: 'No data',
				color: '#e6eeff'
			},{
				from: .0001,
				to: 10,
				color: '#b3d9ff',
				name: '<10'
			}, {
				from: 10.001,
				to: 50,
				color: '#80bfff',
				name: '10-50'
			}, {
				from: 50.001,
				to: 100,
				color: '#3399ff',
				name: '50-100'
			}, {
				from: 100.001,
				to: 300,
				color: '#0073e6',
				name: '100-300'
			}, {
				from: 300.001,
				to: 500,
				color: '#1a8cff',
				name: '300-500'
			}, {
				from: 500.001,
				to: 1000,
				color: '#004d99',
				name: '500-1000'
			}, {
				from: 1000.001,
				to: 80000,
				color: '#001a33',
				name: '>1000'
			}]
        },			
		
		legend: {
			title: {
				text: 'Total Successful Projects',
			},
		},
		
        series: [{
			animation: {
				duration: 3000
			},
            data: data,
            mapData: Highcharts.maps['custom/world'],
            joinBy: ['iso-a2', 'code'],
			dataLabels: {
                enabled: true,
                format: '{point.name}'
            },
            name: 'Total successful projects per country',
			allowPointSelect: true,
			cursor: 'pointer',
            states: {
                hover: {
                    color: '#d6d6f5',
					borderWidth: 1 ,
					borderColor: '#000000'
                }
            },
			
			point: {
				events: {
					click: pointClick
				}
			},
			
			tooltip: {
				useHTML: true,
                pointFormat: '<span class="f32"><span class="flag {point.flag} "></span></span>' +
				' <b> {point.name}:</b> {point.value} sucessful projects <br>Rank: {point.rank} out of 166 countries.',
				valueSuffix: ' ',
				positioner: function () {
                    return { x: 10, y: 250 };
                }				
			}
        }]
    });

    });
});