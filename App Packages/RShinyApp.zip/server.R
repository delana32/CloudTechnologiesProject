library(shiny)
library(DT)
library(sqldf)
library(here)
library(readr)
library(readxl)
library(ggplot2)
require(rpart)
require(rpart.plot)

# Define server logic
shinyServer(function(input, output)
{

	
  #Read in the data
  myData <- read.csv("C:\\Users\\Amy\\Documents\\CloudTech\\CT_App\\kickstarter_data.csv", header = TRUE)
  
  #Output the initial table
  output$kickstarterTable = DT::renderDataTable({myData})
  
  #Update the table using the Action Button
  observeEvent(input$UPDATE, {
    count <- 0
    
    #Build the query
    query <- 'SELECT * FROM myData '
    if (!input$CATEGORY == ""){
      if(count == 0){
        query <- paste(query, paste('where category = "', paste(input$CATEGORY, '" ', collapse = "", sep = ""), collapse = "", sep = ""), collapse = "", sep = "")
      }
      else{
        query <- paste(query, paste('and category = "', paste(input$CATEGORY, '" ', collapse = "", sep = ""), collapse = "", sep = ""), collapse = "", sep = "")
      }
      count = count + 1
    }
    
    if (!input$COUNTRY == ""){
      if(count == 0){
        query <- paste(query, paste('where country = "', paste(input$COUNTRY, '" ', collapse = "", sep = ""), collapse = "", sep = ""), collapse = "", sep = "")
      }
      else{
        query <- paste(query, paste('and country = "', paste(input$COUNTRY, '" ', collapse = "", sep = ""), collapse = "", sep = ""), collapse = "", sep = "")
      }
      count = count + 1
    }
    if (!input$ID == ""){
      if(count == 0){
        query <- paste(query, paste('where creator_id = "', paste(input$ID, '" ', collapse = "", sep = ""), collapse = "", sep = ""), collapse = "", sep = "")
      }
      else{
        query <- paste(query, paste('and creator_id = "', paste(input$ID, '" ', collapse = "", sep = ""), collapse = "", sep = ""), collapse = "", sep = "")
      }
      count = count + 1
    }
    
    if (!input$GOAL == ""){
      if(count == 0){
        query <- paste(query, paste('where goal ', input$GOAL, collapse = "", sep = ""), collapse = "", sep = "")
      }
      else{
        query <- paste(query, paste('and goal ', input$GOAL, collapse = "", sep = ""), collapse = "", sep = "")
      }
      count = count + 1
    }
    
    if (!input$PLEDGED == ""){
      if(count == 0){
        query <- paste(query, paste('where pledged ', input$GOAL, collapse = "", sep = ""), collapse = "", sep = "")
      }
      else{
        query <- paste(query, paste('and pledged ', input$GOAL, collapse = "", sep = ""), collapse = "", sep = "")
      }
      count = count + 1
    }
    if (input$SUCCESS == "Successful" || input$SUCCESS == "successful"){
      if(count == 0){
        query <- paste(query, 'where state = "successful" ')
      }
      else{
        query <- paste(query, 'and state = "successful" ')
      }
      count = count + 1
    }
    
   if (input$SUCCESS == "Failed" || input$SUCCESS == "failed"){
      if(count == 0){
        query <- paste(query, 'where state = "failed" ')
      }
      else{
        query <- paste(query, 'and state = "failed" ')
      }
      count = count + 1
    }
    cat(query)

    #Query the data
    myData <- read.csv.sql("C:\\Users\\Amy\\Documents\\CloudTech\\CT_App\\kickstarter_data.csv", sql = query, header = TRUE)
    
    #Output the updated table
    output$kickstarterTable = DT::renderDataTable({myData})
  })
  
  dataset <- read.csv("C:\\Users\\Amy\\Documents\\CloudTech\\CT_App\\kickstarter_data.csv", header = TRUE)
  
  output$caption <- renderPrint({
	input$x_field
  })
  output$Print <- renderPrint({
	dataset$input$x_field
  })
  
  output$datasum <- renderPrint({
	
	header <- c('Metric', 'Successful', 'Failed', 'Total')
	totprojects <- c('Projects', length(dataset$name[dataset$state == 'successful']), length(dataset$name[dataset$state != 'successful']), length(dataset$name))
	proportion = c('Rate', round((length(dataset$name[dataset$state == 'successful'])/total)*100,2), round((length(dataset$name[dataset$state != 'successful'])/total)*100,2),round(length(length(dataset$name)/total)*100,2))
	x = rbind(header, totprojects, proportion)
	x
  })
  
  TYPE <-reactive(input$variable)
  
  #cutoff <- reactive(input$threshhold)
  output$category <- renderPlot({
  
	if (TYPE() == 'tot_pledge') {
	
		category_A <- read_delim("C:\\Users\\Amy\\Documents\\CloudTech\\CT_App\\category.txt", "\t", escape_double = FALSE, trim_ws = TRUE)
		d <- ggplot(category_A, aes(x=category, y=total_pledged)) + geom_bar(stat="identity")
		d + aes(x = reorder(category, -total_pledged, sum), y = total_pledged, label = total_pledged, fill = state) + theme(axis.text.x = element_text(angle = 60, hjust = 1)) +labs(x='Category', y='Total Pledged ($)', title = 'Top 10 Categories by Pledged Amount', caption = 'The Top 10 categories of Kickstarter Projects can be viewed here in descending order. It seems that Video Games earn the most money for Kickstarter Projects')
	}
	else if (TYPE() == 'avg_pledge') {
		category_1 <- read_delim("C:\\Users\\Amy\\Documents\\CloudTech\\CT_App\\category_avg.txt", "\t", escape_double = FALSE, trim_ws = TRUE)
		p <- ggplot(category_1, aes(x=category, y=avg_pledge, colour = state)) + geom_point()
		p + theme(axis.text.x = element_text(angle = 60, hjust = 1)) +labs(x='Category', y='Avg Pledge Amount ($)', title = 'Top 10 Categories by Avg Pledge Amount', caption = 'The Top 10 categories of Kickstarter Projects can be viewed here in descending order. It seems that successful projects have a higher average pledge')
	}
	else if (TYPE() == 'fxrate') {
		FX_Data <- read_excel("C:\\Users\\Amy\\Documents\\CloudTech\\CT_App/FX Data.xlsx")
		data <- FX_Data[order(FX_Data$Date),]
		q <- ggplot(data, aes(x=Date, y=static_usd_rate, colour = currency))+geom_line()
		q+labs(x='Date', y='USD currency conversion rate', title = 'FX Rate over time')
	
	}
	else if (TYPE() == 'goal') {
		 dataset_goal = subset(dataset, goal < input$threshhold)
		 dataset_success = subset(dataset_goal, state == 'successful')
		 dataset_fail = subset(dataset_goal, state == 'failed')
		 dataset_live = subset(dataset_goal, state == 'live')
		 dataset_cancel = subset(dataset_goal, state == 'suspended')
		
		 no_success = length(dataset_success$state)
		 no_fail = length(dataset_fail$state)
		 no_live = length(dataset_live$state)
		 no_cancel = length(dataset_cancel$state)
		 
		 head <- c('state', 'count_data')
		 count_success <- c('successful', no_success)
		 count_fail <- c('failed', no_fail)
		 count_live <- c('live', no_live)
		 count_cancel <- c('suspended', no_cancel)
		
		 data_goal <- rbind(count_success, count_fail, count_live, count_cancel)
		 data_goal <- as.data.frame(data_goal)
		 row.names(data_goal) <- NULL 
		 colnames(data_goal) <- head
		 
		 #data_goal <- data_goal[order(-data_goal$count_data),]
		 s <- ggplot(data_goal, aes(x = state,y = count_data)) + geom_bar(fill = "dark blue", stat = "identity") +scale_x_discrete(limits= data_goal$state)
		 s  +aes(x= reorder(state, count_data)) + labs(x='State', y='No. of Projects', title = 'No. of Projects with selected goal') +geom_text(aes(label=count_data),position="stack",vjust=0)
	}
	
	
  })
  
  
  
  output$goal <- renderPlot({
	 dataset_goal = subset(dataset, goal < input$threshhold)
	 dataset_success = subset(dataset_goal, state == 'successful')
	 dataset_fail = subset(dataset_goal, state == 'failed')
	 dataset_live = subset(dataset_goal, state == 'live')
	 dataset_cancel = subset(dataset_goal, state == 'suspended')
	
 	 no_success = length(dataset_success$state)
	 no_fail = length(dataset_fail$state)
	 no_live = length(dataset_live$state)
	 no_cancel = length(dataset_cancel$state)
	 
	 head <- c('state', 'count_data')
	 count_success <- c('successful', no_success)
	 count_fail <- c('failed', no_fail)
	 count_live <- c('live', no_live)
	 count_cancel <- c('suspended', no_cancel)
	
     data_goal <- rbind(count_success, count_fail, count_live, count_cancel)
	 data_goal <- as.data.frame(data_goal)
	 row.names(data_goal) <- NULL 
	 colnames(data_goal) <- head
	 
	 #data_goal <- data_goal[order(-data_goal$count_data),]
	 s <- ggplot(data_goal, aes(x = state,y = count_data)) + geom_bar(fill = "dark blue", stat = "identity") +scale_x_discrete(limits= data_goal$state)
	 s  +aes(x= reorder(state, count_data)) + labs(x='State', y='No. of Projects', title = 'No. of Projects with selected goal') +geom_text(aes(label=count_data),position="stack",vjust=0)
	 
  
  
  })
  
 
	output$tfidf <- DT::renderDataTable({
	data_tfidf <- read_excel("C:\\Users\\Amy\\Documents\\CloudTech\\CT_App\\TOP 100 Creators.xlsx")
	data_tfidf$IDF <- NULL
	data_tfidf
	})
	
	observeEvent(input$ENTER, {
		TOP <-reactive(input$TOP)
		STATE <-reactive(input$STATE)
		CREATOR_ID <-reactive(input$CREATOR_ID)
		data_tfidf <- read_excel("C:\\Users\\Amy\\Documents\\CloudTech\\CT_App\\TOP 100 Creators.xlsx")
		data_tfidf$IDF <- NULL
		
		if (STATE()== "")
		{
		
		}
		else
		data_tfidf = subset(data_tfidf, State == input$STATE)
		#output$tfidf <- DT::renderDataTable({data_tfidf})
		
		if (CREATOR_ID()== "")	
		{
			output$tfidf <- DT::renderDataTable({data_tfidf})
			if (STATE()== "")
			{
				output$tfidf <- DT::renderDataTable({data_tfidf})
			}
			else 
			{
			
				output$tfidf <- DT::renderDataTable({data_tfidf})
			
			}
		}
		else 
		{
		
			if (STATE()== "")
			{
				output$tfidf <- DT::renderDataTable({data_tfidf})
			}
			else
			{
				data_tfidf <- subset(data_tfidf, Creator_ID== input$CREATOR_ID)
				data_tfidf <- data_tfidf[with(data_tfidf, order(-TFIDF)), ]
			
				if (TOP() == "5")
				{	
					data_tfidf <- head(data_tfidf,5)
					output$tfidf <- DT::renderDataTable({data_tfidf})
				}
				
				
				
				else if (TOP() =="10") {
					data_tfidf <- head(data_tfidf,10)
					output$tfidf <- DT::renderDataTable({data_tfidf})
				
				}
				else if (TOP() =="All") {
					output$tfidf <- DT::renderDataTable({data_tfidf})
			
				}
			}
		}
	})
		
		
		
		
		
		
	
	
	
  
  
   TREE_TYPE <-reactive(input$tree_type)
   observeEvent(input$ENTER_TREE, {
  #cutoff <- reactive(input$threshhold)
	
	
	if (TREE_TYPE() == 'Tree1') {
   
  
		
		tree_data <- subset(dataset, state =='successful'  || state == 'failed')
		dt = sort(sample(nrow(tree_data), nrow(tree_data)*.7))
		train<-tree_data[dt,]
		test<-tree_data[-dt,]
		
		decision_tree <- rpart(state~goal+backers_count, train)
		output$Tree1 <- renderPlot({rpart.plot(decision_tree)})
		
		
		pred <- predict(decision_tree, test)
		value <- colnames(pred)[apply(pred,1,which.max)]
		test["pred"] <- value
		total <- length(test$state)
		test_yes <- subset(test, state ==pred)
		test_no <- subset(test, state !=pred)
		no_correct <- length(test_yes$pred)
		no_wrong <- length(test_no$pred)
		output$Tree2 <- renderPrint({print(paste0("% Accuracy: ", no_correct/total))})
				
				
				
				
			
		
		
	}
	else  {
			
		tree_data <- subset(dataset, state =='successful'  || state == 'failed')
		dt = sort(sample(nrow(tree_data), nrow(tree_data)*.7))
		train<-tree_data[dt,]
		test<-tree_data[-dt,]
		
		decision_tree <- rpart(state~pledged+goal+backers_count, train)
		output$Tree1 <- renderPlot({rpart.plot(decision_tree)})
		
		
		pred <- predict(decision_tree, test)
		value <- colnames(pred)[apply(pred,1,which.max)]
		test["pred"] <- value
		total <- length(test$state)
		test_yes <- subset(test, state ==pred)
		test_no <- subset(test, state !=pred)
		no_correct <- length(test_yes$pred)
		no_wrong <- length(test_no$pred)
		output$Tree2 <- renderPrint({print(paste0("% Accuracy with test data: ", no_correct/total))})
	
	
	}
	
  })

})

