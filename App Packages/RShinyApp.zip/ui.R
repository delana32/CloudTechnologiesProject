library(shiny)
library(DT)
library(sqldf)

# Define UI for application
shinyUI(navbarPage("Kickstarter Data",

		tabPanel("Data",
		
				sidebarPanel(
				 textInput("CATEGORY", "Enter a category below"),
				  textInput("COUNTRY", "Enter a country below"),
				  textInput("ID", "Enter a creator ID below"),
				  textInput("GOAL", "Enter an operator followed by a goal amount (eg. = 10, > 20, <= 30)"),
				  textInput("PLEDGED", "Enter an operator followed by a pledged amount (eg. = 10, > 20, <= 30)"),
				  textInput("SUCCESS", 'Enter "Successful" or "Failed"'),
				  actionButton("UPDATE", "Update")
  
				),
				 mainPanel(
					DT::dataTableOutput("kickstarterTable")
				 
				 
				)
		),
		tabPanel("Data Visualisations",
			sidebarPanel(
				selectInput("variable", "Choose View to Display", list("Total Pledged Amount ($)" = "tot_pledge", "Average Pledged Amount ($)" = "avg_pledge", "FX Rates to USD" = "fxrate", "Goal Investigation" = "goal")),
				sliderInput("threshhold", "Enter the Project Goal Cutoff Amount ($):", min=0, max = 100000, value = 10000)
		
			),
			mainPanel(
				plotOutput("category")
			)
			
		),
		tabPanel("Decision Tree",
			sidebarPanel(
				selectInput("tree_type", "Choose columns to use in prediction: ", list("Goal & Backers Count" = "Tree1", "Goal, Backers Count & Pledged" = "Tree2")),
				actionButton("ENTER_TREE", "Generate Plot")
			),
			mainPanel(
				plotOutput("Tree1"),
				textOutput("Tree2")
				
			)
		),
		tabPanel("TF-IDF Output",
			sidebarPanel(
				textInput("CREATOR_ID", "Enter a Creator ID below"),
				textInput("STATE", "Enter  'Successful' or 'Failed'"),
				#sliderInput("TOP", "Choose number of records to return: ", min=0, max = 50, value = 10),
				selectInput("TOP", "Choose number of records to return: ", list("Top 5" = "5","Top 10" ="10","All" = "All")),
				actionButton("ENTER", "Enter")
				
			),
			mainPanel(
				DT::dataTableOutput("tfidf")
			)
		)
			
		
    # Application title
    #headerPanel("Kickstarter Data"),
    
    # Sidebar with options for use to search by
   # sidebarPanel(
   #   textInput("CATEGORY", "Enter a category below"),
    #  textInput("COUNTRY", "Enter a country below"),
     # textInput("GOAL", "Enter a numerical goal below"),
     # textInput("SUCCESS", 'Enter "Successful" or "Failed"'),
      #actionButton("UPDATE", "Update"),
	 # selectInput("variable", "Choose View to Display",
      #          list("Total Pledged Amount ($)" = "tot_pledge", 
       #              "Average Pledged Amount ($)" = "avg_pledge",
		#			 "FX Rates to USD" = "fxrate",
		#			 "Goal Investigation" = "goal"
		#			 )),
					 
	 # sliderInput("threshhold", "Enter the Project Goal Cutoff Amount ($):", min=0, max = 100000, value = 10000)
#    ),
                   
    
    #Show the table
 #   mainPanel(
	
	#	tabsetPanel(
	#	tabPanel("Data", DT::dataTableOutput("kickstarterTable")),
	#	tabPanel("Data Visualisations",plotOutput("category") ),
	#	tabPanel("Decision Tree",plotOutput("Tree")),
	#	tabPanel("TF-IDF Output",DT::dataTableOutput("tfidf"))
	#
	#	
	#)
     
    #)
  
  )
)